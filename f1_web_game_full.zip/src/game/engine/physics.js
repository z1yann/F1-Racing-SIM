export function createCarState() {
  return {
    pos: { x: 0, y: 0, z: 0 },
    vel: { x: 0, y: 0, z: 0 },
    rotY: 0,
    angularVel: 0,
    speed: 0,
    wheelSpin: 0,
    gear: 1,
    rpm: 1000,
    mass: 740,
    tyreWear: 0,
    fuel: 100,
  }
}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function localToWorld(vx,vz,yaw){const c=Math.cos(yaw), s=Math.sin(yaw); return {x: vx*c - vz*s, z: vx*s + vz*c}}
function computeLongitudinalForce(state,input,params){
  const engineTorque = params.enginePower * input.throttle
  const driveForce = engineTorque * params.drivetrainEfficiency
  const speed = state.speed
  const drag = 0.5 * params.airDensity * params.dragCoeff * params.frontalArea * speed * speed
  const rolling = params.rollingResistance * state.mass * 9.81
  const brakeForce = input.brake * params.maxBrake
  return driveForce - drag - rolling - brakeForce
}
function computeLateral(state,steerInput,params){
  const turningRadius = Math.max(4.0, 6 / Math.max(0.01, Math.abs(steerInput)))
  const targetAngular = (state.speed / turningRadius) * Math.sign(steerInput || 1)
  const grip = params.baseGrip * (1 - state.tyreWear * params.tyreWearFactor)
  const angularCorrection = clamp((targetAngular - state.angularVel) * grip * 0.5, -params.maxAngularAccel, params.maxAngularAccel)
  return angularCorrection
}
export function applyInputAndIntegrate(state,input,dt,params){
  const longForce = computeLongitudinalForce(state,input,params)
  const accel = longForce / state.mass
  state.speed += accel * dt
  state.speed = clamp(state.speed, -5, params.maxSpeed)
  state.rpm = clamp(1000 + Math.abs(state.speed) * 50 * (1 + state.gear * 0.2), 800, params.redline)
  const angularAccel = computeLateral(state,input.steer,params)
  state.angularVel += angularAccel * dt
  state.rotY += state.angularVel * dt
  const worldV = localToWorld(state.speed,0,state.rotY)
  state.vel.x = worldV.x; state.vel.z = worldV.z
  state.pos.x += state.vel.x * dt; state.pos.z += state.vel.z * dt
  const wearRate = params.baseWearRate * (0.2 + Math.abs(input.throttle) + Math.abs(input.brake))
  state.tyreWear = clamp(state.tyreWear + wearRate * dt, 0, 0.98)
  const fuelRate = params.fuelConsumption * Math.abs(input.throttle) * dt
  state.fuel = Math.max(0, state.fuel - fuelRate)
  state.wheelSpin += state.speed * dt * 10
  return state
}
export const DEFAULT_PHYSICS_PARAMS = {
  enginePower: 16000,
  drivetrainEfficiency: 0.85,
  airDensity: 1.225,
  dragCoeff: 0.9,
  frontalArea: 1.2,
  rollingResistance: 0.015,
  maxBrake: 15000,
  baseGrip: 3.0,
  tyreWearFactor: 0.9,
  baseWearRate: 0.0008,
  fuelConsumption: 0.02,
  maxSpeed: 110,
  redline: 12000,
  maxAngularAccel: 3.5,
}
