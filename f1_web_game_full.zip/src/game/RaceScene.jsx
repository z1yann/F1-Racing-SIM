import React, { useRef, useEffect } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, useGLTF } from '@react-three/drei'
import { createCarState, applyInputAndIntegrate, DEFAULT_PHYSICS_PARAMS } from './engine/physics.js'
import useCarSounds from '../hooks/useCarSounds.js'

function CarVisual({ state }){
  const gltf = useGLTF('/src/assets/car_sample.glb', true)
  return (
    <group position={[state.pos.x, 0.2, state.pos.z]} rotation={[0, state.rotY, 0]}>
      {gltf?.scene ? <primitive object={gltf.scene} /> : (
        <mesh>
          <boxGeometry args={[2.2,0.4,1]} />
          <meshStandardMaterial color={'#ff2d95'} />
        </mesh>
      )}
    </group>
  )
}

export default function RaceScene(){
  const state = useRef(createCarState())
  useCarSounds(()=> state.current?.speed || 0)
  useFrame((_, delta) => {
    const k = {
      w: !!(window.keys && window.keys['w']),
      s: !!(window.keys && window.keys['s']),
      a: !!(window.keys && window.keys['a']),
      d: !!(window.keys && window.keys['d']),
    }
    const input = { throttle: k.w ? 1:0, brake: k.s?1:0, steer: (k.a?-1:0)+(k.d?1:0) }
    applyInputAndIntegrate(state.current, input, delta, DEFAULT_PHYSICS_PARAMS)
  })
  useEffect(()=> {
    // basic key state tracking
    window.keys = {}
    const down = e => window.keys[e.key.toLowerCase()] = true
    const up = e => window.keys[e.key.toLowerCase()] = false
    window.addEventListener('keydown', down); window.addEventListener('keyup', up)
    return ()=> { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up) }
  },[])
  return (
    <Canvas shadows camera={{position:[0,6,12], fov:60}}>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5,10,7]} intensity={1} />
      <mesh rotation={[-Math.PI/2,0,0]} receiveShadow>
        <planeGeometry args={[500,500]} />
        <meshStandardMaterial color={'#0b0b0b'} />
      </mesh>
      <CarVisual state={state.current} />
      <OrbitControls target={[state.current.pos.x,0.5,state.current.pos.z]} enablePan={false} />
    </Canvas>
  )
}
