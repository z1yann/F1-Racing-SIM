import { useEffect, useRef } from 'react'
const ENGINE_LOW = '/src/assets/engine_low.mp3'
const ENGINE_HIGH = '/src/assets/engine_high.mp3'

export default function useCarSounds(getSpeed){
  const lowRef = useRef(null)
  const highRef = useRef(null)
  useEffect(()=>{
    lowRef.current = new Audio(ENGINE_LOW)
    highRef.current = new Audio(ENGINE_HIGH)
    lowRef.current.loop = true
    highRef.current.loop = true
    lowRef.current.volume = 0.7
    highRef.current.volume = 0
    lowRef.current.play().catch(()=>{})
    highRef.current.play().catch(()=>{})
    return () => {
      lowRef.current && lowRef.current.pause()
      highRef.current && highRef.current.pause()
    }
  },[])

  useEffect(()=>{
    let t = setInterval(()=>{
      const speed = typeof getSpeed === 'function' ? getSpeed() : 0
      const mix = Math.min(speed/150,1)
      if(lowRef.current) lowRef.current.volume = 1 - mix
      if(highRef.current) highRef.current.volume = mix
    },120)
    return ()=> clearInterval(t)
  },[getSpeed])
}
