import React from 'react'
import RaceScene from './game/RaceScene.jsx'

export default function F1WebGame({ onExit }){
  return (
    <div className="w-screen h-screen">
      <button onClick={onExit} className="absolute top-6 left-6 z-50 px-4 py-2 rounded bg-white/20">Exit</button>
      <RaceScene />
    </div>
  )
}
