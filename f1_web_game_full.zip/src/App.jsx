import React, { useState } from 'react'
import StartMenu from './StartMenu.jsx'
import F1WebGame from './F1WebGame.jsx'

export default function App(){
  const [started, setStarted] = useState(false)
  return started ? <F1WebGame onExit={() => setStarted(false)} /> : <StartMenu onStart={() => setStarted(true)} />
}
