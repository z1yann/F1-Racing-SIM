import React, { useRef, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, useGLTF } from '@react-three/drei'
import { CAR_SAMPLE_GLb } from './assets/car_sample.glb'

function AnimatedCar(){
  const gltf = useGLTF(CAR_SAMPLE_GLb, true)
  return (
    <group position={[0,-0.5,0]} rotation={[0, Math.PI/6, 0]} scale={[0.9,0.9,0.9]}>
      {gltf?.scene ? <primitive object={gltf.scene} /> : (
        <mesh>
          <boxGeometry args={[2.2,0.4,1]} />
          <meshStandardMaterial color={"#ff2d95"} metalness={0.6} roughness={0.2} />
        </mesh>
      )}
    </group>
  )
}

export default function StartMenu({ onStart }){
  const audioRef = useRef(null)
  useEffect(() => {
    if(audioRef.current){
      audioRef.current.volume = 0.5
      audioRef.current.loop = true
      const play = () => { audioRef.current.play().catch(()=>{}); window.removeEventListener('click', play) }
      window.addEventListener('click', play)
    }
  },[])

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-8 text-white">
      <audio ref={audioRef} src="/src/assets/menu_music.mp3" />
      <div className="grid grid-cols-2 gap-6 max-w-6xl w-full items-center">
        <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-lg shadow-neon">
          <motion.h1 className="text-6xl font-extrabold mb-4" animate={{ textShadow: ["0 0 20px #ff00e0","0 0 40px #00ffe0","0 0 20px #ff00e0"] }} transition={{ repeat: Infinity, duration: 3 }}>
            F1 Neon Racing
          </motion.h1>
          <p className="text-lg opacity-90 mb-6">Fast • Loud • Futuristic</p>
          <motion.button whileHover={{ scale: 1.08 }} whileTap={{ scale: 0.96 }} onClick={onStart} className="px-10 py-4 text-2xl rounded-2xl bg-gradient-to-r from-fuchsia-500 to-purple-600 shadow-neon">
            Start Racing 🏁
          </motion.button>
        </div>

        <div className="relative p-4 rounded-3xl bg-white/3 backdrop-blur-lg">
          <Canvas style={{height: 360}} camera={{position: [0,4,8], fov:50}}>
            <ambientLight intensity={0.6} />
            <directionalLight position={[5,5,5]} intensity={1} />
            <AnimatedCar />
            <OrbitControls enablePan={false} enableZoom={true} />
          </Canvas>
          <Particles />
        </div>
      </div>
    </div>
  )
}

function Particles(){
  useEffect(()=> {
    const cvs = document.getElementById('particles-canvas')
    if(!cvs) return
    const ctx = cvs.getContext('2d')
    let w = cvs.width = cvs.clientWidth
    let h = cvs.height = cvs.clientHeight
    const particles = Array.from({length:40}).map(()=>({x:Math.random()*w,y:Math.random()*h,dx:(Math.random()-0.5)*0.6,dy:(Math.random()-0.5)*0.6,r:Math.random()*2+1,c:`hsl(${Math.random()*360},80%,60%)`}))
    let raf
    function loop(){
      ctx.clearRect(0,0,w,h)
      for(const p of particles){
        p.x += p.dx; p.y += p.dy
        if(p.x<0) p.x=w; if(p.x>w) p.x=0
        if(p.y<0) p.y=h; if(p.y>h) p.y=0
        ctx.beginPath(); ctx.fillStyle=p.c; ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill()
      }
      raf = requestAnimationFrame(loop)
    }
    loop()
    window.addEventListener('resize', ()=>{ w=cvs.width=cvs.clientWidth; h=cvs.height=cvs.clientHeight })
    return ()=>{ cancelAnimationFrame(raf) }
  },[])
  return <canvas id="particles-canvas" style={{position:'absolute', inset:0, pointerEvents:'none'}} />
}
