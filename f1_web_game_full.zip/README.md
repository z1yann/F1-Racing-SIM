# F1 Neon Racing — Web Game

This is a ready-to-deploy React + Vite project for the F1 Neon Racing prototype.

Features included:
- Neon Start Menu with animated 3D car preview
- Background menu music (placeholder)
- Particles overlay on the menu
- 3D Race Scene with WASD controls
- Simple vehicle physics engine
- Car engine sounds that crossfade with speed
- Multiple arenas/tracks scaffold (add your models)

How to run locally:
1. npm install
2. npm run dev
3. Open the local URL printed by Vite

Notes:
- Replace placeholder audio files in src/assets/ with real MP3s for music and engine sounds.
- Replace src/assets/car_sample.glb with a real GLB model for a better preview.
- This project is set up for deployment to Netlify/Vercel/GitHub Pages.
